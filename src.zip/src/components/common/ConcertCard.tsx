// src/components/common/ConcertCard.tsx
import { Link } from "react-router-dom";
import type { Ticket } from "../../types/ticket";
import type { Concert } from "../../mocks/ranking.mock";

/** Ticket 또는 Concert 중 하나만 받도록 하는 교차 타입 */
type Props =
  | { ticket: Ticket; concert?: never }
  | { ticket?: never; concert: Concert };

/** 화면 표시용 공통 뷰 모델 */
type View = {
  id: string;
  title: string;
  cover: string;
  period: string;
  venue: string;
};

/** 사용자 정의 타입 가드 */
function hasPeriod(c: Concert | Record<string, unknown>): c is Concert & { period: string } {
  return "period" in c && typeof (c as any).period === "string";
}
function hasDates(
  c: Concert | Record<string, unknown>
): c is Concert & { dateStart?: string; dateEnd?: string } {
  return "dateStart" in c || "dateEnd" in c;
}

/** Concert -> View 로 변환 (type-safe) */
function concertToView(c: Concert): View {
  const cover = (c as any).cover ?? c.imageUrl ?? "";

  let period = "";
  if (hasPeriod(c)) {
    period = c.period;
  } else if (hasDates(c)) {
    const ds = (c as any).dateStart as string | undefined;
    const de = (c as any).dateEnd as string | undefined;
    period = ds && de ? `${ds} ~ ${de}` : ds ?? "";
  }

  return {
    id: c.id,
    title: (c as any).title ?? "",
    cover,
    period,
    venue: (c as any).venue ?? "",
  };
}

/** Ticket -> View 로 변환 */
function ticketToView(t: Ticket): View {
  const period = t.dateEnd ? `${t.dateStart} ~ ${t.dateEnd}` : t.dateStart;
  return {
    id: t.id,
    title: t.title,
    cover: t.cover,
    period,
    venue: t.venue ?? "",
  };
}

export default function ConcertCard(props: Props) {
  const view: View = props.ticket ? ticketToView(props.ticket) : concertToView(props.concert!);

  return (
    <Link
      to={`/concert/${view.id}`}
      className="block overflow-hidden rounded-xl border bg-white shadow-sm transition hover:shadow-md dark:border-neutral-800 dark:bg-neutral-900"
    >
      <img src={view.cover} alt={view.title} className="h-56 w-full object-cover" loading="lazy" />
      <div className="px-3 py-2">
        <h3 className="line-clamp-1 text-sm font-medium">{view.title}</h3>
        {view.venue && <p className="mt-1 text-xs text-neutral-500">{view.venue}</p>}
        {view.period && <p className="mt-1 text-xs text-neutral-500">{view.period}</p>}
      </div>
    </Link>
  );
}
