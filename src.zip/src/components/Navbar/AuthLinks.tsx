import { Link } from "react-router-dom";

export default function AuthLinks() {
  return (
    <div className="flex items-center gap-2">
      <Link className="hover:underline" to="/login">로그인</Link>
      <span className="text-slate-400">|</span>
      <Link className="hover:underline" to="/signup">회원가입</Link>
    </div>
  );
}
