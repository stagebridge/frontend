import { useState } from "react";

export default function NotificationIcon() {
  const [count, setCount] = useState(3); // 목데이터
  const loggedIn = true; // 추후 인증 연동

  return (
    <button
      type="button"
      aria-label="알림"
      title={loggedIn ? "알림" : "로그인 후 이용 가능"}
      className="relative text-xl"
      disabled={!loggedIn}
    >
      🔔
      {loggedIn && count > 0 && (
        <span
          className="absolute -top-1 -right-1 rounded-full bg-red-500 px-1 text-[10px] text-white"
        >
          {count}
        </span>
      )}
    </button>
  );
}
