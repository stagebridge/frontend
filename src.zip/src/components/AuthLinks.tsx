// src/components/AuthLinks.tsx
import { Link } from "react-router-dom";
import { useAuth } from "../contexts/AuthContext";

export default function AuthLinks() {
  const { user, isAuthed, logout } = useAuth();

  if (isAuthed && user) {
    return (
      <div className="flex items-center gap-3">
        <span className="text-[15px] text-slate-700 dark:text-slate-200">
          <strong>{user.nickname}</strong> 님 환영합니다
        </span>
        <button
          onClick={logout}
          className="rounded-lg border px-3 py-1.5 text-sm dark:border-neutral-700"
        >
          로그아웃
        </button>
      </div>
    );
  }

  return (
    <div className="text-[15px]">
      <Link to="/login" className="hover:underline">로그인</Link>
      <span className="mx-2 text-neutral-400">|</span>
      <Link to="/signup" className="hover:underline">회원가입</Link>
    </div>
  );
}
